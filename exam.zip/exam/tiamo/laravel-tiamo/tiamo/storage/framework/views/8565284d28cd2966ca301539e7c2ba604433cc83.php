<div class="row viewed">
<p class="viewed-text">Недавно просмотренные</p>
    <?php if(session('viewed')): ?>
        <?php $__currentLoopData = session('viewed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $details['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($image["isdefaultImg"] ==1): ?>

                    <div class="col col-xxl-3 mg-30"><a href="<?php echo e(route('card', $id)); ?>"><img class="viewed-card" src="../img/<?php echo e($image['image']); ?>" alt=""></a></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--     <?php else: ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($image->isdefaultImg == 1): ?>
                    <div class="col col-xxl-3"><img class="viewed-card" src="../img/<?php echo e($image['image']); ?>" alt=""></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
    <?php endif; ?>
</div><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/widgets/last_viewed_widget.blade.php ENDPATH**/ ?>