<div class="fill">
    <?php $__currentLoopData = $fifth_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img class="fill-img" src="./img/<?php echo e($item->image); ?>" alt="">
        <div class="fill-des">
            <p class="gradient"><?php echo e($item->description); ?> </p>
            <img src="./img/arrow-down.svg" alt="">
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/widgets/main_fifth_section_widget.blade.php ENDPATH**/ ?>