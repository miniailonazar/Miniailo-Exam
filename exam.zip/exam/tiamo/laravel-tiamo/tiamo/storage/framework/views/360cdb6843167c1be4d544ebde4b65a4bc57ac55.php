
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('css/catalog.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

      <!-- banner -->
      <?php echo app('arrilot.widget')->run('sm_banner_widget'); ?>
      <?php if(url()->current()=="http://127.0.0.1:8000/catalog-brand/2"): ?>
      <p class="name-collection"><a href="<?php echo e(route('index')); ?>">TIAMO</a> | exlusive</p>
      <?php else: ?>
      <p class="name-collection"><a href="<?php echo e(route('index')); ?>">TIAMO</a></p>
      <?php endif; ?>
      <p class="name-new-collection">NEW COLLECTION</p>
      <!-- video -->
      <?php echo app('arrilot.widget')->run('main_video_widget'); ?>
      <!-- filter -->
  <div class="filter">
        <div class="style">
        <div class="dropdown dropdown-btn">
        <button class="btn  dropdown-toggle" type="button"  id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
          Dropdown button
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="#">Action</a></li>
          <li><a class="dropdown-item" href="#">Another action</a></li>
          <li><a class="dropdown-item" href="#">Something else here</a></li>
        </ul>
      </div>
      <div class="dropdown dropdown-btn">
        <button class="btn  dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
          Dropdown button
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
          <li><a class="dropdown-item" href="#">Action</a></li>
          <li><a class="dropdown-item" href="#">Another action</a></li>
          <li><a class="dropdown-item" href="#">Something else here</a></li>
        </ul>
      </div>
    </div>
    <div class="sort">
      <select class="form-select form-select-sm select" aria-label=".form-select-sm example">
        <option selected>Open this select menu</option>
        <option  value="1">One</option>
        <option  value="2">Two</option>
        <option  value="3">Three</option>
      </select>
  </div>
    </div>
    <!-- end-filter -->
    <div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col col-xxl-4 ">
        
            <a href="<?php echo e(route('card', $product->id)); ?>">
              <div class="card" style="width: 400px;">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($image->isdefaultImg == 1): ?>
                        <img src="../img/<?php echo e($image->image); ?>" class="card-img-top"alt="<?php echo e($image->image); ?>">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($product->name_product); ?></h5>
                  <p class="card-price"><?php echo e($product->price); ?> ₴</p>
                </div>
              </div>
            </a>
        
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>  
        <?php echo e($products->links("pagination::bootstrap-4")); ?>

<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/catalog.blade.php ENDPATH**/ ?>