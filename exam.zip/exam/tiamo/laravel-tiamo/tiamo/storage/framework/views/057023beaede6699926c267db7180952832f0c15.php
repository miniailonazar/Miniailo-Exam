
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('css/card.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- banner -->
<?php echo app('arrilot.widget')->run('sm_banner_widget'); ?>
      <!-- крошки -->
      <p class="name-collection">TIAMO | Свадебные платья | Gabrielle</p>
      <!-- end-крошки -->
      <div class="row">
        <!--  -->
        
        <div class="col col-xxl-6 content-card pdl-90">
          <?php $__currentLoopData = $product->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <iframe  src="<?php echo e($video->link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="main-cards"></iframe>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
            <div ><img  class="main-cards" src="../img/<?php echo e($image->image); ?>" alt="<?php echo e($image->image); ?>"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col col-xxl-6 content-description">
          <div class="first-name">
          <p class="des-dress"><?php echo e($product->name_product); ?> 
        </div>
        <?php if(!empty($product->price_hire)): ?>
        <div class="price">
          <p class="last-price" style="text-decoration: line-through;"> <?php echo e($product->price); ?> грн </p>
          <p class="new-price"><?php echo e($product->price_hire); ?> грн</p>
        </div>
        <p class="sale"><?php echo e($product->price_hire_text); ?></p>
        <?php else: ?>
        <div class="price">
          <p class="last-price"> <?php echo e($product->price); ?> грн </p>
        </div>
        <?php endif; ?>
        <div class="text-color">
          <p class="fw-500">Цвет:</p> <p class="name-color fw-500">белый</p>
        </div>
        <div class="colour" id="colour">
          <div id="white" class="colour-square" OnClick="colour(this);">
            <div class="square" style="background: white;"></div>
          </div>
          <div class="colour-square" OnClick="colour(this);">
            <div class="square" style="background: black;"></div>
          </div>
        </div>
        <div class="table-size"><img src="../img/trempel.svg" alt=""> <p class="table"> <u>Таблица размеров</u> </p></div>
        <div class="size">

        </div>
        <div class="logo-sale">
          <div class="logo1"><img src="../img/img1.svg" alt=""></div>
          <div class="logo1"><img src="../img/img2.svg" alt=""></div>
        </div>
        <div class="sale-btn">
          <a href="<?php echo e(route('add.to.cart', $product->id)); ?>"><div class="btn-sale">В корзину</div></a>
          <div class="btn-sale">Примерить в салоне</div>
        </div>
        <a href="<?php echo e(route('add.to.wish', $product->id)); ?>"><div class="wish-list"><img src="../img/heart.svg" alt=""> <p class="wish"> Добавить в wishlist </p>
        </div></a>
        <div class="seria extra"> <p>Reference:</p> <p class="seria-text">154V06AM013_X0835 </p></div>
        <div class="extra"><img src="./img/characteristics.svg" alt=""><p class="extra-text"> Характеристики </p></div>
        <div class="extra"><img src="./img/box.svg" alt=""><p class="extra-text"> Доставка и оплата </p></div>
        <div class="extra"><img src="./img/share.svg" alt=""><p class="extra-text"> Поделиться </p>
        </div>
        </div>
      </div>

<?php echo app('arrilot.widget')->run('like_product_widget'); ?>
<?php echo app('arrilot.widget')->run('last_viewed_widget'); ?>
      <?php $__env->startSection('scripts'); ?>
      <script type="text/javascript">
    function colour(arg)
{
    alert(arg);
    let parent = document.getElementById("colour").childNodes;
    alert(parent);
    arg.style.borderBottom= "2px solid #000000" ;
}
</script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/card.blade.php ENDPATH**/ ?>