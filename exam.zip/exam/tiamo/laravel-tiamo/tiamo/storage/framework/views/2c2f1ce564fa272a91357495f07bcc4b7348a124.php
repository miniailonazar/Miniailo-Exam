<div class="row">
<?php $__currentLoopData = $first_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col col-xxl-4"><img class="first-card" src="../img/<?php echo e($item->image); ?>" alt=""></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/widgets/main_first_section_widget.blade.php ENDPATH**/ ?>