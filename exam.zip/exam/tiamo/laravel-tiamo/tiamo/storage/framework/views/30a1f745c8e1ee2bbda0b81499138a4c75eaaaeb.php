<div class="row like">
    <p class="like-text">Вам может понравиться</p>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($image->isdefaultImg == 1): ?>
                <div class="col col-xxl-4"><a href="<?php echo e(route('card', $product->id)); ?>"><img class="like-card" src="../img/<?php echo e($image->image); ?>" alt=""></a></div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
<?php echo e($products->links("pagination::bootstrap-4")); ?><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/widgets/like_product_widget.blade.php ENDPATH**/ ?>