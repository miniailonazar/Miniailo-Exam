<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($category->status == 1): ?>
    <li><a class="dropdown-item nav-h2" href="<?php echo e(route('catalogstyle', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Nazar\OSPanel\domains\tiamo\laravel-tiamo\tiamo\resources\views/widgets/nav_style_widget.blade.php ENDPATH**/ ?>