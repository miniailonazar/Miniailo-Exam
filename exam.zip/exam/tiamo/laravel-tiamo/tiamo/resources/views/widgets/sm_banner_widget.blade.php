@foreach($small as $item)
<div class="sm-baner"><img src="../img/{{$item->image}}" alt="sm-baner"></div>
@endforeach