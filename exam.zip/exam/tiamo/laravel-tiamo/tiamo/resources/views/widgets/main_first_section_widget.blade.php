<div class="row">
@foreach($first_section as $item)
<div class="col col-xxl-4"><img class="first-card" src="../img/{{$item->image}}" alt=""></div>
@endforeach
</div>