<div class="row">
@foreach($fourth_section as $item)
<div class="col col-xxl-6"><img class="client-cart" src="../img/{{$item->image}}" alt=""></div>
@endforeach
</div>