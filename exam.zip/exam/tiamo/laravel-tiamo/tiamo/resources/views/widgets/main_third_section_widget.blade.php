
<div class="row al-items-center">
        <div class="col col-xxl-4"><img class="small-cart" src="../img/{{$third_section['0']->image}}" alt=""></div>
        <div class="col col-xxl-4"><img class="medium-cart" src="../img/{{$third_section['1']->image}}" alt=""></div>
        <div class="col col-xxl-4"><img class="large-cart" src="../img/{{$third_section['2']->image}}" alt=""></div>
    </div>