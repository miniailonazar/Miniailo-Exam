@foreach($images->product as $product)
echo {{$product->name}}

@endforeach