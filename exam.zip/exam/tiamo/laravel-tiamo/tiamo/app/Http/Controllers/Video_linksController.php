<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Video_linksController extends Controller
{
    //
}
